$(document).ready(function(){


  var body = $('body');
        var html = $('html');
        var link = $('.menu-link');
        var link_active = $('.menu-link_active');
        var menu_ul = $('.menu_ul');
        var nav_link = $('.menu_ul a')
        var menu_over = $('.burger-menu_overlay')
        var menu_over_a = $('.burger-menu_overlay-act')

        link.click(function(){
            link.toggleClass('menu-link_active');
            body.toggleClass('fixed');
            html.toggleClass('fixed');
            menu_ul.toggleClass('menu_ul_active');
            menu_over.toggleClass('burger-menu_overlay-act');
        });
        nav_link.click(function(){
            link.toggleClass('menu-link_active');
            menu_ul.toggleClass('menu_ul_active');
            menu_over.removeClass('burger-menu_overlay-act')
        });



    $('.your-class').slick({
      dots: false,
      infinite: true,
      speed: 1000,
      // autoplay: true,
      autoplaySpeed: 10000,
      slidesToShow: 4,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1199,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: true,
            dots: false,
          }
        },
        {
          breakpoint: 1023,
          settings: {
          dots: true,
          arrows:false,
          autoplaySpeed: 5000,
          slidesToShow: 2,
          slidesToScroll: 1,
          }
        },
        {
          breakpoint: 767,
          settings: {
            autoplay:false,
            dots: true,
            arrows:false,
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 500,
          settings: {
            autoplay:false,
            dots: true,
            arrows:false,
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]
    });

    
  $('.mat-slaider').slick({
    dots: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 6,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
          infinite: true,
          dots: false,
        }
      },
      {
        breakpoint: 1023,
        settings: {
          dots: true,
          arrows:false,
          slidesToShow: 3,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 767,
        settings: {
          dots: true,
          arrows:false,
          slidesToShow: 2,
          slidesToScroll: 1
        }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ]
  });

  });












  $('.imp-proj__hole').slick({
    dots: false,
    arrows:true,
    infinite: false,
    speed: 1000,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: false,
          dots: false
        }
      },
      {
        breakpoint: 1023,
        settings: {
          dots: true,
          arrows:false,
          slidesToShow: 2,
          slidesToScroll: 1,
          variableWidth: false,
        }
      },
      {
        breakpoint: 767,
        settings: {
          autoplay:false,
          dots: true,
          arrows:false,
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 500,
        settings: {
          autoplay:false,
          dots: true,
          arrows:false,
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ]
  });



  $('.multiple-items').slick({
    infinite: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          dots: false,
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: false,
          dots: false,
          arrows:true,
        }
      },
      {
        breakpoint: 1023,
        settings: {
          dots: true,
          arrows:false,
          slidesToShow: 2,
          slidesToScroll: 1,
          variableWidth: false,
        }
      },
      {
        breakpoint: 767,
        settings: {
          dots: true,
          arrows:false,
          slidesToShow: 2,
          slidesToScroll: 1
        }
      }
      ,
      {
        breakpoint: 550,
        settings: {
          dots: true,
          arrows:false,
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ]
  });

  $('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    fade: true,
    asNavFor: '.slider-nav',
    
  });

  $('.slider-nav').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows:false,
    asNavFor: '.slider-for',
    dots: false,
    focusOnSelect: true,
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          dots: false,
          slidesToShow: 4,
          slidesToScroll: 1,
          infinite: false,
          dots: false
        }
      },
      {
        breakpoint: 1023,
        settings: {
          dots: false,
          arrows:false,
          slidesToShow: 4,
          slidesToScroll: 1,
          variableWidth: false,
        }
      },
      {
        breakpoint: 767,
        settings: {
          dots: false,
          arrows:false,
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 500,
        settings: {
          dots: false,
          arrows:false,
          slidesToShow: 2,
          slidesToScroll: 1
        }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ]
  });


  // $('.ui-tabs-anchor').click(function () {
  //   $(".imp-proj__hole").slick('slickSetOption', 'adaptiveHeight', true, true);
  // });
  $('.ui-tabs-anchor').on('click', function (e) {
    $(".imp-proj__hole").slick('reinit');
    });


  $( function() {
    $( "#tabs" ).tabs();
  } );


  $('.filtr_media__menu').click(function(){
    $('.filters').toggleClass('filters_active');
    $('.content-place').toggleClass('.content-place_active');
  })
  $('.active-filt').click(function(){
    $('.filters_active').removeClass('filters_active');
  })


  $(function () {
    $("#filter__range").slider({
     min: 0,
     max: 20000,
     values: [5000,15000],
     range: true,
     stop: function(event, ui) {
       $("input#priceMin").val($("#filter__range").slider("values",0));
       $("input#priceMax").val($("#filter__range").slider("values",1));
 
       $('.price-range-min.value').html($("#filter__range").slider("values",0));
       $('.price-range-max.value').html($("#filter__range").slider("values",1));
     },
     slide: function(event, ui){
       $("input#priceMin").val($("#filter__range").slider("values",0));
       $("input#priceMax").val($("#filter__range").slider("values",1));
 
       $('.price-range-min.value').html($("#filter__range").slider("values",0));
       $('.price-range-max.value').html($("#filter__range").slider("values",1));
     }
   });
 
   $("input#priceMin").on('change', function(){
     var value1=$("input#priceMin").val();
     var value2=$("input#priceMax").val();
     if(parseInt(value1) > parseInt(value2)){
       value1 = value2;
       $("input#priceMin").val(value1);
       $('.price-range-min.value').html(value1);
     }
     $("#filter__range").slider("values", 0, value1);
     $('.price-range-min.value').html(value1);
   });
 
   $("input#priceMax").on('change', function(){
     var value1=$("input#priceMin").val();
     var value2=$("input#priceMax").val();
     if (value2 > 20000) { value2 = 20000; $("input#priceMax").val(35000)}
     if(parseInt(value1) > parseInt(value2)){
       value2 = value1;
       $("input#priceMax").val(value2);
       $('.price-range-max.value').html(value2);
     }
     $("#filter__range").slider("values",1,value2);
     $('.price-range-max.value').html(value2);
   });
 
   $('.ui-slider-handle:eq(0)').append('<span class="price-range-min value">' + $('#filter__range').slider('values', 0 ) + '</span>');
   $('.ui-slider-handle:eq(1)').append('<span class="price-range-max value">' + $('#filter__range').slider('values', 1 ) + '</span>');
 });



  var swiper = new Swiper('.swiper', {
    slidesPerView: 4.5,
    direction: getDirection(),
    direction:'horizontal',
    loop: true,
    autoplay: {
      delay: 10000,
      disableOnInteraction: false,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    
    on: {
      init() {
        this.el.addEventListener('mouseenter', () => {
          this.autoplay.stop();
        });
  
        this.el.addEventListener('mouseleave', () => {
          this.autoplay.start();
        });
      }
    },

    breakpoints: {
      // mobile + tablet - 320-990
      320: {
        slidesPerView: 1.25
      },
      // desktop >= 991
      600: {
        slidesPerView: 2.5
      },
      1024:{
        slidesPerView: 3.5
      },
      1365:{
        slidesPerView: 4.5
      },
    }
  });


  jQuery(function($){
    $("#phone").mask("+7 (999) 999-9999");
 });

  function getDirection() {
    var windowWidth = window.innerWidth;
    var direction = window.innerWidth <= 760 ? 'vertical' : 'horizontal';

    return direction;
  }